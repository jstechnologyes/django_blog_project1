
from django.urls import path
from  . import views


urlpatterns = [
    path('', views.index.as_view(), name="index"),
    path('author/<name>', views.getauthor.as_view(), name="author"),
    path('article/<int:id>', views.getsingle, name="single_post"),
    path('topic/<name>', views.gettopic, name="topic"),
    path('login', views.getLogin, name="login"),
    path('logout', views.getLogout, name="logout"),
    path('create/', views.getcreate, name="create"),
    path('profile/', views.getProfile, name="profile"),
    path('update/<int:pid>', views.getUpdeat, name="update"),
    path('delete/<int:pid>', views.getDelete, name="delete"),
    path('register', views.getRegister, name="register"),
    path('category', views.getCategory, name="category"),
    path('create/category', views.getCreateCategory, name="create_category")
]
